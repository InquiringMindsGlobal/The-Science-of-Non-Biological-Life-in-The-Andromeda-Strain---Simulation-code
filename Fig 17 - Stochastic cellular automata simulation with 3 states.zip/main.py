# Stochastic cellular automata simulation with 3 states
import random
import numpy as np
import matplotlib.pyplot as plt

# Parameters
width = 200       # number of cells
steps = 150       # number of time steps
p_t = 0.3         # templating probability at endpoints
p_n = 0.002       # spontaneous misfolding probability
p_r = 0.002       # reversion probability
p_b = 0.1         # fragmentation probability per cluster per step

# Rule 110 lookup table (binary projection)
rule_110 = {
    (1,1,1):0,(1,1,0):1,(1,0,1):1,(1,0,0):0,
    (0,1,1):1,(0,1,0):1,(0,0,1):1,(0,0,0):0,
}

def is_endpoint(g,i):
    if g[i] != 2: return False
    left  = g[i-1] if i>0 else 0
    right = g[i+1] if i<len(g)-1 else 0
    return (left != 2) or (right != 2)

def apply_fragmentation(g):
    """Break long misfolded clusters into visible gaps."""
    i = 0
    while i < len(g):
        if g[i] == 2:
            j = i
            while j < len(g) and g[j] == 2:
                j += 1
            length = j - i
            if length > 5 and random.random() < p_b:
                # choose a gap inside the cluster
                gap_start = random.randint(i+1, j-3)
                gap_size  = random.randint(2, min(6, j-gap_start-1))
                for k in range(gap_start, gap_start+gap_size):
                    g[k] = 1  # revert to native, creating a visible gap
            i = j
        else:
            i += 1
    return g

# Initialize grid
grid = [random.choice([0,1]) for _ in range(width)]
for _ in range(3):
    grid[random.randint(0, width-1)] = 2

# Simulation
history = []
for step in range(steps):
    new_grid = grid[:]
    for i in range(width):
        left = grid[i-1] if i>0 else 0
        center = grid[i]
        right = grid[i+1] if i<width-1 else 0

        l_proj = 1 if left==1 else 0
        c_proj = 1 if center==1 else 0
        r_proj = 1 if right==1 else 0
        base_state = rule_110[(l_proj,c_proj,r_proj)]

        if center == 0:
            new_grid[i] = base_state
        elif center == 1:
            new_grid[i] = base_state
            left_ep  = (i>0 and is_endpoint(grid,i-1))
            right_ep = (i<width-1 and is_endpoint(grid,i+1))
            if (left_ep or right_ep) and random.random() < p_t:
                new_grid[i] = 2
            elif random.random() < p_n:
                new_grid[i] = 2
        elif center == 2:
            new_grid[i] = 1 if random.random() < p_r else 2

    grid = apply_fragmentation(new_grid)
    history.append(grid[:])

# Convert to RGB image
colors = {0:[255,255,255], 1:[0,0,0], 2:[255,0,0]}
img = np.array([[colors[c] for c in row] for row in history], dtype=np.uint8)

# Plot
plt.figure(figsize=(12,8), dpi=150)
plt.imshow(img, aspect='auto', interpolation='nearest')
plt.title("Prion-style Rule 110 with Gap-based Fragmentation")
plt.axis('off')
plt.show()

