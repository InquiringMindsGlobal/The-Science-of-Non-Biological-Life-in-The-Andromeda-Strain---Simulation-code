# Fig 20 - Simulation experimental results metrics comparisons
import random
import numpy as np
import matplotlib.pyplot as plt

# Shared parameters
width = 200
steps = 120
p_tip = 0.25
p_heal = 0.15
p_diss_base = 0.0008

# Rule 110 texture
rule_110 = {
    (1,1,1):0,(1,1,0):1,(1,0,1):1,(1,0,0):0,
    (0,1,1):1,(0,1,0):1,(0,0,1):1,(0,0,0):0,
}

def is_tip(g,i):
    if g[i] != 1: return False
    return (g[(i-1)%len(g)] != 1) or (g[(i+1)%len(g)] != 1)

def near_crystal(g,i):
    return g[(i-1)%len(g)] == 1 or g[(i+1)%len(g)] == 1

def apply_rule110_texture(g):
    n = len(g); new = g[:]
    for i in range(n):
        left = 1 if g[(i-1)%n] == 1 else 0
        center = 1 if g[i] == 1 else 0
        right = 1 if g[(i+1)%n] == 1 else 0
        base = rule_110[(left, center, right)]
        if g[i] != 2: new[i] = 1 if base == 1 else 0
    return new

def simulate_scenario(R0, consumption, diffusion, p_nuc, p_branch,
                      total_budget, boundary_leak, seed=42):
    random.seed(seed); np.random.seed(seed)
    grid = [0]*width
    center = width//2
    for k in range(center-2, center+3): grid[k] = 1
    R = [R0]*width

    asymmetry_idx = []
    branch_counts = []
    order_param = []

    consumed_total = 0

    def step(g,R,consumed_total):
        n = len(g); new = g[:]; branching_count = 0
        # Tip growth
        for i in range(n):
            if g[i] == 0 and R[i] > consumption and consumed_total < total_budget:
                if (is_tip(g,(i-1)%n) or is_tip(g,(i+1)%n)) and random.random() < p_tip:
                    new[i] = 1; R[i] -= consumption; consumed_total += consumption
        # Branching
        for i in range(n):
            if g[i] == 1 and is_tip(g,i) and random.random() < p_branch:
                target = (i + random.choice([-1,+1])) % n
                if new[target] == 0:
                    new[target] = 2; branching_count += 1
        # Healing & dissolution
        for i in range(n):
            if g[i] == 2 and near_crystal(g,i) and random.random() < p_heal:
                new[i] = 1
            elif g[i] == 1:
                p_diss_eff = p_diss_base + max(0, (0.2 - R[i]))*0.01
                if random.random() < p_diss_eff:
                    new[i] = 0
        # Nucleation
        for i in range(n):
            if new[i] == 0 and R[i] > consumption and consumed_total < total_budget:
                if random.random() < p_nuc:
                    new[i] = 1; R[i] -= consumption; consumed_total += consumption
        # Texture
        textured = apply_rule110_texture(new)
        for i in range(n):
            if new[i] == 2: textured[i] = 2
        # Resource diffusion + boundary leakage
        R_new = R[:]
        for i in range(n):
            R_new[i] += diffusion * (R[(i-1)%n] + R[(i+1)%n] - 2*R[i])
        R_new[0] *= (1-boundary_leak)
        R_new[-1] *= (1-boundary_leak)
        return textured, R_new, branching_count, consumed_total

    for _ in range(steps):
        grid, R, bcount, consumed_total = step(grid, R, consumed_total)
        # Metrics
        left_extent = center
        for i in range(center, -1, -1):
            if grid[i] == 1: left_extent = i; break
        right_extent = center
        for i in range(center, width):
            if grid[i] == 1: right_extent = i
        diff = abs((center - left_extent) - (right_extent - center))
        asymmetry_idx.append(diff/(width/2))  # normalized 0–1
        branch_counts.append(bcount)
        order_param.append(sum(1 for c in grid if c==1)/width)

    return np.array(asymmetry_idx), np.array(branch_counts), np.array(order_param)

# Scenarios
scenarios = {
    "Low scarcity":      dict(R0=0.7,  consumption=0.03, diffusion=0.20, p_nuc=0.004,  p_branch=0.05, total_budget=5000, boundary_leak=0.0),
    "Moderate scarcity": dict(R0=0.5,  consumption=0.05, diffusion=0.10, p_nuc=0.001,  p_branch=0.02, total_budget=2000, boundary_leak=0.01),
    "High scarcity":     dict(R0=0.35, consumption=0.08, diffusion=0.06, p_nuc=0.0005, p_branch=0.01, total_budget=1000, boundary_leak=0.02),
    "Extreme scarcity":  dict(R0=0.2,  consumption=0.10, diffusion=0.02, p_nuc=0.0002, p_branch=0.005, total_budget=500,  boundary_leak=0.05),
}

# Multi-seed averaging
Nseeds = 20
results = {}
for name, params in scenarios.items():
    asym_all = []; branch_all = []; order_all = []
    for s in range(Nseeds):
        a,b,o = simulate_scenario(**params, seed=100+s)
        asym_all.append(a); branch_all.append(b); order_all.append(o)
    results[name] = {
        "asym_mean": np.mean(asym_all, axis=0),
        "asym_std": np.std(asym_all, axis=0),
        "branch_mean": np.mean(branch_all, axis=0),
        "branch_std": np.std(branch_all, axis=0),
        "order_mean": np.mean(order_all, axis=0),
        "order_std": np.std(order_all, axis=0),
    }

# Plot comparison dashboard
fig, axes = plt.subplots(3,1, figsize=(12,10), dpi=140)
colors = {"Low scarcity":"#1f77b4","Moderate scarcity":"#ff7f0e",
          "High scarcity":"#2ca02c","Extreme scarcity":"#d62728"}

for name, res in results.items():
    t = np.arange(steps)
    axes[0].plot(t, res["asym_mean"], label=name, color=colors[name])
    axes[0].fill_between(t, res["asym_mean"]-res["asym_std"], res["asym_mean"]+res["asym_std"], color=colors[name], alpha=0.2)
    axes[1].plot(t, res["branch_mean"], label=name, color=colors[name])
    axes[1].fill_between(t, res["branch_mean"]-res["branch_std"], res["branch_mean"]+res["branch_std"], color=colors[name], alpha=0.2)
    axes[2].plot(t, res["order_mean"], label=name, color=colors[name])
    axes[2].fill_between(t, res["order_mean"]-res["order_std"], res["order_mean"]+res["order_std"], color=colors[name], alpha=0.2)

axes[0].set_title("Normalized Asymmetry Index (0–1)")
axes[1].set_title("Branching Count")
axes[2].set_title("Order Parameter")
for ax in axes: ax.legend(); ax.set_xlim(0, steps)
plt.tight_layout(); plt.show()

