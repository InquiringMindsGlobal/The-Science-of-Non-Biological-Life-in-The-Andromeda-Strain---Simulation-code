# Stochastic cellular automata simulation with 2 states
import numpy as np

def get_next_state(left, center, right, probabilities):
    """
    Determines the next state of the center cell based on the triplet
    and the defined stochastic probabilities.
    """
    triplet = (left, center, right)
    
    # --- RULE 110 DETERMINISTIC MAPPING ---
    # The key to stochastic modeling is deciding which deterministic Rule 110
    # outcomes (0 or 1) are now governed by probability.
    
    # Triplet map: (111, 110, 101, 100, 011, 010, 001, 000)
    # R110 Binary: ( 0 ,  1 ,  1 ,  0 ,  1 ,  1 ,  1 ,  0 )
    
    # Example: If the deterministic rule is '1' (misfolding), we apply a probability P_misfold.
    # If the deterministic rule is '0' (stability), we might apply a low probability P_spont_misfold
    # to account for spontaneous events.
    
    if triplet == (1, 1, 1):
        # Deterministic R110: 0 (Stable Fibril)
        # Apply clearance or stability probability
        return 0 # Often kept deterministic '0' for stable cores
    
    elif triplet in [(1, 1, 0), (0, 1, 1), (1, 0, 1)]:
        # Deterministic R110: 1 (Replication/Growth)
        # Apply P_misfold: The biological conversion step
        if np.random.rand() < probabilities['P_misfold']:
            return 1  # Misfold occurs
        else:
            return 0  # Conversion fails due to energy barrier, protein clearance, etc.
            
    elif triplet in [(0, 1, 0), (0, 0, 1)]:
        # Deterministic R110: 1 (Edge Recruitment/Initiation)
        # Use a separate probability P_initiate, as edge events might be different
        if np.random.rand() < probabilities['P_initiate']:
            return 1
        else:
            return 0
            
    elif triplet == (1, 0, 0):
        # Deterministic R110: 0 (Stability/Clearance)
        # Option 1: Keep 0 for stability. Option 2: Introduce P_spont_misfold (low probability)
        # For simplicity in this template, we keep the stable state '0'
        return 0
        
    elif triplet == (0, 0, 0):
        # Deterministic R110: 0 (Healthy)
        # Option 1: Introduce P_spont_misfold to model de novo generation.
        if np.random.rand() < probabilities['P_spont_misfold']:
             return 1
        else:
             return 0

def simulate_stochastic_ca(initial_state, num_steps, probabilities, boundary_condition='periodic'):
    """
    Runs the 1D Stochastic Cellular Automata simulation.
    """
    N = len(initial_state)
    history = [np.copy(initial_state)] # Store the evolution
    current_state = np.copy(initial_state)
    
    for t in range(num_steps):
        next_state = np.zeros(N, dtype=int)
        
        for i in range(N):
            # --- Handle Boundary Conditions ---
            if boundary_condition == 'periodic':
                L = current_state[(i - 1) % N] # Left neighbor
                C = current_state[i]         # Center cell
                R = current_state[(i + 1) % N] # Right neighbor
            elif boundary_condition == 'fixed':
                # Fixed boundary (e.g., 0s outside)
                L = current_state[i - 1] if i > 0 else 0
                C = current_state[i]
                R = current_state[i + 1] if i < N - 1 else 0
            else:
                raise ValueError("Invalid boundary_condition")
                
            next_state[i] = get_next_state(L, C, R, probabilities)
            
        current_state = next_state
        history.append(np.copy(current_state))
        
    return np.array(history)

# --- SIMULATION SETUP ---
# 1. Define Model Parameters
N_CELLS = 200        # Size of the 1D lattice (number of PrP molecules)
TIME_STEPS = 150     # Number of time steps (simulated time)

# 2. Define Stochastic Probabilities (KEY BIOLOGICAL PARAMETERS)
# The student would need to tune these!
STOCHASTIC_PARAMS = {
    'P_misfold': 0.9,         # High probability for established PrPsc to replicate (110, 101, 011)
    'P_initiate': 0.7,        # Lower probability for solitary PrPsc to recruit (010, 001)
    'P_spont_misfold': 0.005  # Very low probability for PrPc (000) to misfold spontaneously (de novo)
}

# 3. Define Initial State (Seed for Prion Replication)
# Start with a single misfolded cluster ('1') in the center.
initial_state = np.zeros(N_CELLS, dtype=int)
# Seed the PrPsc cluster (e.g., a small fibril nucleus)
initial_state[N_CELLS // 2 - 2 : N_CELLS // 2 + 3] = 1 

# --- RUN SIMULATION ---
print(f"Starting Stochastic CA Simulation (N={N_CELLS}, T={TIME_STEPS}) with P_misfold={STOCHASTIC_PARAMS['P_misfold']}")
evolution_data = simulate_stochastic_ca(
    initial_state, 
    TIME_STEPS, 
    STOCHASTIC_PARAMS, 
    boundary_condition='periodic'
)

# --- VISUALIZATION (Requires matplotlib) ---
try:
    import matplotlib.pyplot as plt
    
    plt.figure(figsize=(10, 6))
    plt.imshow(evolution_data, cmap='binary', interpolation='nearest', aspect='auto')
    plt.title('Stochastic CA Rule 110 Evolution (Prion Replication Model)')
    plt.xlabel('Cell Position (Protein Molecule)')
    plt.ylabel('Time Step')
    plt.show()
except ImportError:
    print("\nInstall matplotlib (`pip install matplotlib`) to visualize the results.")
    print("Evolution Data Shape:", evolution_data.shape)

