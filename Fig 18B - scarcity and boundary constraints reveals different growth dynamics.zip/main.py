# Fig 18B - scarcity and boundary constraints reveals different growth dynamics
import random
import numpy as np
import matplotlib.pyplot as plt

# Parameters
width = 200
steps = 120

# Probabilities
p_nuc = 0.001     # spontaneous nucleation
p_tip = 0.25      # tip-driven growth
p_branch = 0.02   # branching event
p_heal = 0.15     # defect healing
p_diss = 0.0008   # dissolution

# Resource parameters
R0 = 0.5          # initial resource level (scarcity knob)
consumption = 0.05 # resource consumed per growth
diffusion = 0.1   # diffusion rate

# Constraint budget
global_budget = 20  # max growth events per timestep

# Rule 110 texture
rule_110 = {
    (1,1,1):0,(1,1,0):1,(1,0,1):1,(1,0,0):0,
    (0,1,1):1,(0,1,0):1,(0,0,1):1,(0,0,0):0,
}

# Initialize grid and resource field
grid = [0]*width
center = width//2
for k in range(center-2, center+3): grid[k] = 1
R = [R0]*width

def is_tip(g,i):
    if g[i] != 1: return False
    left  = g[(i-1) % len(g)]
    right = g[(i+1) % len(g)]
    return (left != 1) or (right != 1)

def near_crystal(g,i):
    return g[(i-1) % len(g)] == 1 or g[(i+1) % len(g)] == 1

def apply_rule110_texture(g):
    n = len(g)
    new = g[:]
    for i in range(n):
        left   = 1 if g[(i-1) % n] == 1 else 0
        center = 1 if g[i] == 1 else 0
        right  = 1 if g[(i+1) % n] == 1 else 0
        base = rule_110[(left, center, right)]
        if g[i] != 2:
            new[i] = 1 if base == 1 else 0
    return new

def step(g,R):
    n = len(g)
    new = g[:]
    events = []

    # Tip-driven growth
    for i in range(n):
        if g[i] == 0 and R[i] > consumption:
            left_tip  = is_tip(g, (i-1) % n)
            right_tip = is_tip(g, (i+1) % n)
            if (left_tip or right_tip) and random.random() < p_tip:
                events.append(("grow", i))

    # Branching
    for i in range(n):
        if g[i] == 1 and is_tip(g,i) and random.random() < p_branch:
            target = (i + random.choice([-1,+1])) % n
            events.append(("branch", target))

    # Apply global budget: prioritize balanced left/right growth
    if len(events) > global_budget:
        left_events = [e for e in events if e[1] < n//2]
        right_events = [e for e in events if e[1] >= n//2]
        # keep balanced subset
        keep = left_events[:global_budget//2] + right_events[:global_budget//2]
    else:
        keep = events

    # Execute events
    for ev, idx in keep:
        if ev == "grow":
            new[idx] = 1
            R[idx] -= consumption
        elif ev == "branch":
            new[idx] = 2

    # Healing and dissolution
    for i in range(n):
        if g[i] == 2 and near_crystal(g,i) and random.random() < p_heal:
            new[i] = 1
        elif g[i] == 1 and random.random() < p_diss:
            new[i] = 0

    # Nucleation
    for i in range(n):
        if new[i] == 0 and R[i] > consumption and random.random() < p_nuc:
            new[i] = 1
            R[i] -= consumption

    # Rule 110 texture
    textured = apply_rule110_texture(new)
    for i in range(n):
        if new[i] == 2:
            textured[i] = 2

    # Resource diffusion
    R_new = R[:]
    for i in range(n):
        R_new[i] += diffusion * (R[(i-1)%n] + R[(i+1)%n] - 2*R[i])
    return textured, R_new

# Run simulation
history = []
grid_current = grid[:]
R_current = R[:]
for _ in range(steps):
    grid_current, R_current = step(grid_current, R_current)
    history.append(grid_current[:])

# Visualization
colors = {0:[255,255,255], 1:[30,120,255], 2:[255,140,0]}
img = np.array([[colors[c] for c in row] for row in history], dtype=np.uint8)

plt.figure(figsize=(12,8), dpi=150)
plt.imshow(img, aspect='auto', interpolation='nearest')
plt.title("Crystal Growth with Scarcity & Constraint Budget")
plt.axis('off')
plt.show()
