# Updating crystal growth simulation to include quantitative metrics and plotting results
import random
import numpy as np
import matplotlib.pyplot as plt

# Parameters
width = 200
steps = 120
p_tip = 0.25
p_nuc = 0.001
p_branch = 0.02
p_heal = 0.15
p_diss = 0.0008
R0 = 0.5
consumption = 0.05
diffusion = 0.1
global_budget = 20.0

# Rule 110
rule_110 = {
    (1,1,1):0,(1,1,0):1,(1,0,1):1,(1,0,0):0,
    (0,1,1):1,(0,1,0):1,(0,0,1):1,(0,0,0):0,
}

# Initialize grid and concentration
grid = [0]*width
center = width//2
for k in range(center-2, center+3):
    grid[k] = 1  # initial crystal seed
concentration = [R0]*width

def is_tip(g, i):
    if g[i] != 1: return False
    left = g[(i-1) % len(g)]
    right = g[(i+1) % len(g)]
    return (left != 1) or (right != 1)

def near_crystal(g, i):
    return g[(i-1) % len(g)] == 1 or g[(i+1) % len(g)] == 1

def apply_rule110_texture(g):
    n = len(g)
    new = g[:]
    for i in range(n):
        left = 1 if g[(i-1) % n] == 1 else 0
        center = 1 if g[i] == 1 else 0
        right = 1 if g[(i+1) % n] == 1 else 0
        base = rule_110[(left, center, right)]
        if g[i] != 2:
            new[i] = 1 if base == 1 else 0
    return new

# Metrics
symmetry_index = []
branching_counts = []
order_parameters = []

# Simulation
history = []
grid_current = grid[:]
for step in range(steps):
    new = grid_current[:]
    n = len(grid_current)
    branch_count = 0

    # Tip-driven growth and branching
    for i in range(n):
        if grid_current[i] == 0:
            left_tip = is_tip(grid_current, (i-1) % n)
            right_tip = is_tip(grid_current, (i+1) % n)
            if (left_tip or right_tip) and random.random() < p_tip and concentration[i] > 0.1:
                new[i] = 1
                global_budget -= consumption
                concentration[i] -= consumption
        elif grid_current[i] == 1:
            if is_tip(grid_current, i) and random.random() < p_branch:
                target = (i + random.choice([-1, +1])) % n
                new[target] = 2
                branch_count += 1

    # Defect healing and dissolution
    for i in range(n):
        if grid_current[i] == 2:
            if near_crystal(grid_current, i) and random.random() < p_heal:
                new[i] = 1
        elif grid_current[i] == 1:
            if random.random() < p_diss:
                new[i] = 0

    # Nucleation
    for i in range(n):
        if new[i] == 0 and random.random() < p_nuc and concentration[i] > 0.1:
            new[i] = 1
            global_budget -= consumption
            concentration[i] -= consumption

    # Apply Rule 110 texture
    textured = apply_rule110_texture(new)
    for i in range(n):
        if new[i] == 2:
            textured[i] = 2

    # Update concentration with diffusion
    new_conc = concentration[:]
    for i in range(n):
        left = concentration[(i-1) % n]
        right = concentration[(i+1) % n]
        new_conc[i] += diffusion * (left + right - 2 * concentration[i])
        new_conc[i] = max(0, new_conc[i])
    concentration = new_conc

    # Record metrics
    leftmost = next((i for i in range(n) if textured[i] == 1), 0)
    rightmost = next((i for i in reversed(range(n)) if textured[i] == 1), n-1)
    symmetry = abs(rightmost - (n - 1 - leftmost))
    symmetry_index.append(symmetry)
    branching_counts.append(branch_count)
    order_param = sum(1 for x in textured if x == 1) / n
    order_parameters.append(order_param)

    grid_current = textured
    history.append(grid_current[:])

# Visualization
colors = {0:[255,255,255], 1:[30,120,255], 2:[255,140,0]}
img = np.array([[colors[c] for c in row] for row in history], dtype=np.uint8)

fig, axs = plt.subplots(4, 1, figsize=(12, 16), dpi=150)

# Evolution image
axs[0].imshow(img, aspect='auto', interpolation='nearest')
axs[0].set_title("Crystal Growth Evolution")
axs[0].axis('off')

# Symmetry index
axs[1].plot(symmetry_index, color='purple')
axs[1].set_title("Symmetry Index Over Time")
axs[1].set_ylabel("Symmetry Index")
axs[1].set_xlabel("Time Step")

# Branching count
axs[2].plot(branching_counts, color='orange')
axs[2].set_title("Branching Count Over Time")
axs[2].set_ylabel("New Defects")
axs[2].set_xlabel("Time Step")

# Order parameter
axs[3].plot(order_parameters, color='blue')
axs[3].set_title("Order Parameter Over Time")
axs[3].set_ylabel("Fraction Ordered")
axs[3].set_xlabel("Time Step")

plt.tight_layout()
#plt.savefig("/mnt/data/crystal_growth_metrics.png")
plt.show()
print("Simulation complete. Plotted evolution and metrics: symmetry index, branching count, and order parameter.")

