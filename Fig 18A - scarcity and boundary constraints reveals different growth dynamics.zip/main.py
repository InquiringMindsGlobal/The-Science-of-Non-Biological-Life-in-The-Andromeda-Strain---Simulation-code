# Fig 18A - scarcity and boundary constraints reveals different growth dynamics

import random
import numpy as np
import matplotlib.pyplot as plt

# Parameters
width = 200       # number of cells
steps = 120       # number of time steps

# Probabilities
p_nuc = 0.001     # spontaneous nucleation (0 -> 1)
p_tip = 0.25      # tip-driven growth (0 -> 1 near crystal endpoints)
p_branch = 0.02   # branching event at a tip (creates a defect 2 near the tip)
p_heal = 0.15     # defect healing near ordered lattice (2 -> 1)
p_diss = 0.0008   # rare dissolution (1 -> 0) to keep fronts dynamic

# Rule 110 (applied only to the 1-state projection to add micro-texture)
rule_110 = {
    (1,1,1):0,(1,1,0):1,(1,0,1):1,(1,0,0):0,
    (0,1,1):1,(0,1,0):1,(0,0,1):1,(0,0,0):0,
}

# Initialize: mostly solution with a small symmetric crystal seed
grid = [0]*width
center = width//2
for k in range(center-2, center+3): grid[k] = 1  # small ordered seed

def is_tip(g,i):
    """A crystal endpoint is a 1 adjacent to non-1."""
    if g[i] != 1: return False
    left  = g[(i-1) % len(g)]
    right = g[(i+1) % len(g)]
    return (left != 1) or (right != 1)

def near_crystal(g,i):
    """Check if site i has a crystal neighbor."""
    return g[(i-1) % len(g)] == 1 or g[(i+1) % len(g)] == 1

def apply_rule110_texture(g):
    """Apply Rule 110 to the 1-state projection to create micro-texture inside the ordered band.
       Only affects cells that are currently 0 or 1; defects (2) are handled separately."""
    n = len(g)
    new = g[:]
    for i in range(n):
        left   = 1 if g[(i-1) % n] == 1 else 0
        center = 1 if g[i] == 1 else 0
        right  = 1 if g[(i+1) % n] == 1 else 0
        base = rule_110[(left, center, right)]
        # Map Rule 110 output back into lattice/background:
        # Keep ordered regions cohesive: base=1 favors staying ordered, base=0 favors background.
        if g[i] != 2:  # don't overwrite defects here
            new[i] = 1 if base == 1 else 0
    return new

def step(g):
    n = len(g)
    new = g[:]

    # 1) Tip-driven growth and branching
    for i in range(n):
        if g[i] == 0:
            left_tip  = is_tip(g, (i-1) % n)
            right_tip = is_tip(g, (i+1) % n)
            if (left_tip or right_tip) and random.random() < p_tip:
                new[i] = 1  # crystal grows into solution
        elif g[i] == 1:
            # Occasional branching: create a local defect near the tip
            if is_tip(g, i) and random.random() < p_branch:
                # place a defect either left or right of the tip
                target = (i + random.choice([-1, +1])) % n
                new[target] = 2

    # 2) Defect healing and rare dissolution
    for i in range(n):
        if g[i] == 2:
            if near_crystal(g, i) and random.random() < p_heal:
                new[i] = 1
        elif g[i] == 1:
            if random.random() < p_diss:
                new[i] = 0

    # 3) Rare nucleation in solution (spontaneous seeds)
    for i in range(n):
        if new[i] == 0 and random.random() < p_nuc:
            new[i] = 1

    # 4) Apply Rule 110–based micro-texture to ordered/background only
    textured = apply_rule110_texture(new)

    # 5) Preserve defects from new (texture should not erase them)
    for i in range(n):
        if new[i] == 2:
            textured[i] = 2

    return textured

# Run simulation
history = []
grid_current = grid[:]
for _ in range(steps):
    grid_current = step(grid_current)
    history.append(grid_current[:])

# Color mapping: 0=white (solution), 1=blue (crystal), 2=orange (defect)
colors = {0:[255,255,255], 1:[30, 120, 255], 2:[255,140,0]}
img = np.array([[colors[c] for c in row] for row in history], dtype=np.uint8)

# Plot
plt.figure(figsize=(12,8), dpi=150)
plt.imshow(img, aspect='auto', interpolation='nearest')
plt.title("Crystal Growth on a Rule 110 Backbone (1D)")
plt.axis('off')
plt.show()

